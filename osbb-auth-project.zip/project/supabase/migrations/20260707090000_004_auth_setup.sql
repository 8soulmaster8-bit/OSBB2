/*
# Wire up Supabase Auth for residents / admin (Голова ОСББ)

1. Changes
- `residents.id` now references `auth.users(id)` — every resident row IS
  an authenticated user (one-to-one).
- On sign up, the client passes ФИО / phone / apartment / area / role in
  `auth.users.raw_user_meta_data`. A trigger (`handle_new_user`) reads that
  metadata and automatically inserts the matching `residents` row right
  after the auth user is created — no extra request needed from the app.
- `public.is_admin()` is a SECURITY DEFINER helper used inside RLS
  policies so a policy can check "is the current user an admin" without
  causing recursive RLS evaluation on the `residents` table.

2. Security (RLS)
- Replace the previous anon/demo-mode policies (full open access) with
  policies scoped to `authenticated` users only:
  - Admin (Голова ОСББ) can read/write everything.
  - A resident can read/write only rows that belong to them
    (`residents.id = auth.uid()`, or `resident_id = auth.uid()` /
    via the related meter for `meter_readings`).
- Anonymous (logged-out) access is removed entirely; the app requires an
  authenticated Supabase session.
*/

-- ---------------------------------------------------------------------
-- 1. Link residents to auth.users
-- ---------------------------------------------------------------------

-- Existing demo rows (created before auth existed) have no matching
-- auth.users row, so they must be removed before we can add the FK.
-- Comment this DELETE out if you want to keep them and create matching
-- auth users manually instead.
DELETE FROM meter_readings WHERE meter_id IN (SELECT id FROM meters WHERE resident_id IN (SELECT id FROM residents));
DELETE FROM receipts;
DELETE FROM requests;
DELETE FROM meters;
DELETE FROM residents;

ALTER TABLE residents
  ADD CONSTRAINT residents_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- residents.id is no longer auto-generated: it must match the auth user id.
ALTER TABLE residents ALTER COLUMN id DROP DEFAULT;

-- ---------------------------------------------------------------------
-- 2. Auto-create the resident profile row when someone signs up
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.residents (id, name, apartment, phone, role, area)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.raw_user_meta_data->>'apartment', ''),
    NEW.raw_user_meta_data->>'phone',
    COALESCE(NEW.raw_user_meta_data->>'role', 'resident'),
    COALESCE((NEW.raw_user_meta_data->>'area')::numeric, 50)
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ---------------------------------------------------------------------
-- 3. Helper to check "is the current user an admin" without recursive RLS
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM residents WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- ---------------------------------------------------------------------
-- 4. Replace demo (anon) policies with authenticated, role-aware policies
-- ---------------------------------------------------------------------

-- residents ------------------------------------------------------------
DROP POLICY IF EXISTS "anon_crud_residents" ON residents;
DROP POLICY IF EXISTS "anon_insert_residents" ON residents;
DROP POLICY IF EXISTS "anon_update_residents" ON residents;
DROP POLICY IF EXISTS "anon_delete_residents" ON residents;

CREATE POLICY "residents_select" ON residents
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_admin());

CREATE POLICY "residents_insert_admin" ON residents
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "residents_update" ON residents
  FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.is_admin())
  WITH CHECK (id = auth.uid() OR public.is_admin());

CREATE POLICY "residents_delete_admin" ON residents
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- meters -----------------------------------------------------------------
DROP POLICY IF EXISTS "anon_crud_meters" ON meters;
DROP POLICY IF EXISTS "anon_insert_meters" ON meters;
DROP POLICY IF EXISTS "anon_update_meters" ON meters;
DROP POLICY IF EXISTS "anon_delete_meters" ON meters;

CREATE POLICY "meters_select" ON meters
  FOR SELECT TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "meters_insert" ON meters
  FOR INSERT TO authenticated
  WITH CHECK (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "meters_update" ON meters
  FOR UPDATE TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin())
  WITH CHECK (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "meters_delete_admin" ON meters
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- meter_readings -----------------------------------------------------------
DROP POLICY IF EXISTS "anon_crud_meter_readings" ON meter_readings;
DROP POLICY IF EXISTS "anon_insert_meter_readings" ON meter_readings;
DROP POLICY IF EXISTS "anon_update_meter_readings" ON meter_readings;
DROP POLICY IF EXISTS "anon_delete_meter_readings" ON meter_readings;

CREATE POLICY "meter_readings_select" ON meter_readings
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM meters m WHERE m.id = meter_readings.meter_id AND m.resident_id = auth.uid())
  );

CREATE POLICY "meter_readings_insert" ON meter_readings
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM meters m WHERE m.id = meter_readings.meter_id AND m.resident_id = auth.uid())
  );

CREATE POLICY "meter_readings_delete_admin" ON meter_readings
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- receipts -----------------------------------------------------------------
DROP POLICY IF EXISTS "anon_crud_receipts" ON receipts;
DROP POLICY IF EXISTS "anon_insert_receipts" ON receipts;
DROP POLICY IF EXISTS "anon_update_receipts" ON receipts;
DROP POLICY IF EXISTS "anon_delete_receipts" ON receipts;

CREATE POLICY "receipts_select" ON receipts
  FOR SELECT TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "receipts_insert_admin" ON receipts
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "receipts_update" ON receipts
  FOR UPDATE TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin())
  WITH CHECK (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "receipts_delete" ON receipts
  FOR DELETE TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin());

-- requests (maintenance) -----------------------------------------------------
DROP POLICY IF EXISTS "anon_crud_requests" ON requests;
DROP POLICY IF EXISTS "anon_insert_requests" ON requests;
DROP POLICY IF EXISTS "anon_update_requests" ON requests;
DROP POLICY IF EXISTS "anon_delete_requests" ON requests;

CREATE POLICY "requests_select" ON requests
  FOR SELECT TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "requests_insert" ON requests
  FOR INSERT TO authenticated
  WITH CHECK (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "requests_update" ON requests
  FOR UPDATE TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin())
  WITH CHECK (resident_id = auth.uid() OR public.is_admin());

CREATE POLICY "requests_delete" ON requests
  FOR DELETE TO authenticated
  USING (resident_id = auth.uid() OR public.is_admin());
