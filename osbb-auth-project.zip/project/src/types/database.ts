export interface Resident {
  id: string;
  name: string;
  apartment: string;
  phone: string | null;
  role: 'resident' | 'admin';
  area: number;
  created_at: string;
}

export interface Meter {
  id: string;
  resident_id: string;
  type: 'water' | 'hot_water' | 'cold_water' | 'electricity' | 'gas';
  current_reading: number;
  reading_date: string;
  created_at: string;
  residents?: Resident;
}

export interface MeterReading {
  id: string;
  meter_id: string;
  reading: number;
  reading_date: string;
  submitted_at: string;
  meters?: Meter;
}

export interface Receipt {
  id: string;
  resident_id: string;
  month: string;
  amount: number;
  status: 'paid' | 'unpaid';
  created_at: string;
  residents?: Resident;
}

export interface MaintenanceRequest {
  id: string;
  resident_id: string;
  topic: string;
  description: string | null;
  status: 'new' | 'in_progress' | 'completed';
  master: string | null;
  created_at: string;
  residents?: Resident;
}

export type ViewMode = 'resident' | 'admin';

export type RequestStatus = 'new' | 'in_progress' | 'completed';

export const REQUEST_STATUS_LABELS: Record<RequestStatus, string> = {
  new: 'В обработке',
  in_progress: 'Мастер назначен',
  completed: 'Выполнено',
};
